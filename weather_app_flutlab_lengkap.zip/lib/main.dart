import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

// Mengubah Map data menjadi Map<String, String> untuk dikirim sebagai
// query parameter lewat GET (jalur cadangan pengganti POST). raw_json
// sengaja dilewati agar URL tidak terlalu panjang; field lain yang
// bernilai null juga dilewati.
Map<String, String> toQueryParams(Map<String, dynamic> data) {
  final Map<String, String> result = {};

  data.forEach((key, value) {
    if (key == 'raw_json' || value == null) return;
    result[key] = value.toString();
  });

  return result;
}

// Header User-Agent yang menyerupai browser HP biasa. Beberapa hosting
// memakai sistem bot-protection (misalnya Imunify360) yang memblokir
// request dengan User-Agent bawaan Dart/Flutter karena dianggap bot.
// Header ini "menyamarkan" request supaya diterima seperti request
// dari browser normal.
const Map<String, String> kBrowserLikeHeaders = {
  'User-Agent':
      'Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Accept': 'application/json',
};

void main() {
  runApp(const WeatherApp());
}

class WeatherApp extends StatelessWidget {
  const WeatherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Weather App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.lightBlue,
      ),
      home: const WeatherHomePage(),
    );
  }
}

// ==========================================================
// KONFIGURASI API
// ==========================================================
class ApiConfig {
  // ---- Platform API eksternal: OpenWeatherMap ----
  // Daftar API key gratis di https://home.openweathermap.org/api_keys
  static const String openWeatherApiKey = '408455f23223df49751bb917a9f360e5';

  static const String openWeatherBaseUrl =
      'https://api.openweathermap.org/data/2.5/weather';

  static String iconUrl(String iconCode) =>
      'https://openweathermap.org/img/wn/$iconCode@2x.png';

  // ---- REST API server sendiri (hosting Jagoan Hosting) ----
  // Domain aplikasi: egidiofreitasapi.my.id
  // File PHP di-upload langsung di public_html (root), bukan di subfolder.
  static const String serverListUrl =
      'https://egidiofreitasapi.my.id/list_weather.php';

  static const String serverSaveUrl =
      'https://egidiofreitasapi.my.id/save_weather.php';

  static const String serverUpdateUrl =
      'https://egidiofreitasapi.my.id/update_weather.php';

  static const String serverDeleteUrl =
      'https://egidiofreitasapi.my.id/delete_weather.php';
}

// ==========================================================
// MODEL DATA CUACA
// ==========================================================
class WeatherModel {
  final int? id; // null jika belum tersimpan di database
  final String cityName;
  final String? country;
  final double? latitude;
  final double? longitude;
  final double? temperature;
  final double? feelsLike;
  final double? tempMin;
  final double? tempMax;
  final int? humidity;
  final int? pressure;
  final double? windSpeed;
  final int? windDeg;
  final String? weatherMain;
  final String? weatherDescription;
  final String? weatherIcon;
  bool isFavorite;
  String? notes;
  final String? createdAt;
  final String? updatedAt;
  final Map<String, dynamic> rawJson;

  WeatherModel({
    this.id,
    required this.cityName,
    this.country,
    this.latitude,
    this.longitude,
    this.temperature,
    this.feelsLike,
    this.tempMin,
    this.tempMax,
    this.humidity,
    this.pressure,
    this.windSpeed,
    this.windDeg,
    this.weatherMain,
    this.weatherDescription,
    this.weatherIcon,
    this.isFavorite = false,
    this.notes,
    this.createdAt,
    this.updatedAt,
    required this.rawJson,
  });

  // Data mentah dari OpenWeatherMap API (units=metric)
  factory WeatherModel.fromOpenWeatherJson(Map<String, dynamic> json) {
    final Map<String, dynamic> main = json['main'] is Map<String, dynamic>
        ? json['main'] as Map<String, dynamic>
        : <String, dynamic>{};

    final Map<String, dynamic> wind = json['wind'] is Map<String, dynamic>
        ? json['wind'] as Map<String, dynamic>
        : <String, dynamic>{};

    final Map<String, dynamic> sys = json['sys'] is Map<String, dynamic>
        ? json['sys'] as Map<String, dynamic>
        : <String, dynamic>{};

    final List<dynamic> weatherList =
        json['weather'] is List ? json['weather'] as List : <dynamic>[];

    final Map<String, dynamic> weather =
        weatherList.isNotEmpty && weatherList.first is Map<String, dynamic>
            ? weatherList.first as Map<String, dynamic>
            : <String, dynamic>{};

    final Map<String, dynamic> coord = json['coord'] is Map<String, dynamic>
        ? json['coord'] as Map<String, dynamic>
        : <String, dynamic>{};

    return WeatherModel(
      cityName: json['name']?.toString() ?? 'Tidak diketahui',
      country: sys['country']?.toString(),
      latitude: parseDouble(coord['lat']),
      longitude: parseDouble(coord['lon']),
      temperature: parseDouble(main['temp']),
      feelsLike: parseDouble(main['feels_like']),
      tempMin: parseDouble(main['temp_min']),
      tempMax: parseDouble(main['temp_max']),
      humidity: parseInt(main['humidity']),
      pressure: parseInt(main['pressure']),
      windSpeed: parseDouble(wind['speed']),
      windDeg: parseInt(wind['deg']),
      weatherMain: weather['main']?.toString(),
      weatherDescription: weather['description']?.toString(),
      weatherIcon: weather['icon']?.toString(),
      isFavorite: false,
      notes: null,
      rawJson: json,
    );
  }

  // Data dari REST API server sendiri (tabel weather_history)
  factory WeatherModel.fromServerJson(Map<String, dynamic> json) {
    return WeatherModel(
      id: parseInt(json['id']),
      cityName: json['city_name']?.toString() ?? 'Tidak diketahui',
      country: json['country']?.toString(),
      latitude: parseDouble(json['latitude']),
      longitude: parseDouble(json['longitude']),
      temperature: parseDouble(json['temperature']),
      feelsLike: parseDouble(json['feels_like']),
      tempMin: parseDouble(json['temp_min']),
      tempMax: parseDouble(json['temp_max']),
      humidity: parseInt(json['humidity']),
      pressure: parseInt(json['pressure']),
      windSpeed: parseDouble(json['wind_speed']),
      windDeg: parseInt(json['wind_deg']),
      weatherMain: json['weather_main']?.toString(),
      weatherDescription: json['weather_description']?.toString(),
      weatherIcon: json['weather_icon']?.toString(),
      isFavorite:
          json['is_favorite'].toString() == '1' || json['is_favorite'] == true,
      notes: json['notes']?.toString(),
      createdAt: json['created_at']?.toString(),
      updatedAt: json['updated_at']?.toString(),
      rawJson: json,
    );
  }

  // Data yang dikirim ke REST API server saat INSERT (save_weather.php)
  Map<String, dynamic> toServerJson() {
    return {
      'city_name': cityName,
      'country': country,
      'latitude': latitude,
      'longitude': longitude,
      'temperature': temperature,
      'feels_like': feelsLike,
      'temp_min': tempMin,
      'temp_max': tempMax,
      'humidity': humidity,
      'pressure': pressure,
      'wind_speed': windSpeed,
      'wind_deg': windDeg,
      'weather_main': weatherMain,
      'weather_description': weatherDescription,
      'weather_icon': weatherIcon,
      'is_favorite': isFavorite,
      'notes': notes,
      'raw_json': rawJson,
    };
  }

  static int? parseInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse(value.toString());
  }

  static double? parseDouble(dynamic value) {
    if (value == null) return null;
    if (value is double) return value;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString());
  }
}

// ==========================================================
// HALAMAN UTAMA
// ==========================================================
class WeatherHomePage extends StatefulWidget {
  const WeatherHomePage({super.key});

  @override
  State<WeatherHomePage> createState() => _WeatherHomePageState();
}

class _WeatherHomePageState extends State<WeatherHomePage>
    with SingleTickerProviderStateMixin {
  late final TabController tabController;
  final TextEditingController searchController = TextEditingController();

  WeatherModel? currentWeather;
  List<WeatherModel> historyWeather = [];

  bool isSearching = false;
  bool isSaving = false;
  bool isLoadingHistory = false;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    loadHistoryFromServer();
  }

  @override
  void dispose() {
    tabController.dispose();
    searchController.dispose();
    super.dispose();
  }

  Future<Map<String, dynamic>> decodeJsonResponse(
      http.Response response) async {
    try {
      return jsonDecode(response.body) as Map<String, dynamic>;
    } catch (_) {
      throw Exception(
        'Response server bukan JSON valid. '
        'Status: ${response.statusCode}. '
        'Isi response: ${response.body.substring(0, response.body.length > 200 ? 200 : response.body.length)}',
      );
    }
  }

  // -------------------- 1. AMBIL DATA DARI OPENWEATHERMAP API --------------------
  Future<void> searchWeatherFromApi() async {
    final String city = searchController.text.trim();

    if (city.isEmpty) {
      showMessage('Masukkan nama kota terlebih dahulu.');
      return;
    }

    setState(() {
      isSearching = true;
      currentWeather = null;
    });

    try {
      final Uri uri = Uri.parse(ApiConfig.openWeatherBaseUrl).replace(
        queryParameters: {
          'q': city,
          'appid': ApiConfig.openWeatherApiKey,
          'units': 'metric',
          'lang': 'id',
        },
      );

      final http.Response response = await http.get(uri);
      final Map<String, dynamic> decoded = await decodeJsonResponse(response);

      if (response.statusCode != 200) {
        throw Exception(
          decoded['message']?.toString() ??
              'Kota tidak ditemukan atau terjadi kesalahan API (status ${response.statusCode}).',
        );
      }

      setState(() {
        currentWeather = WeatherModel.fromOpenWeatherJson(decoded);
      });

      showMessage('Data cuaca untuk "$city" berhasil diambil.');
    } catch (e) {
      showMessage('Gagal mengambil data cuaca: $e');
    } finally {
      setState(() {
        isSearching = false;
      });
    }
  }

  // -------------------- 2. SIMPAN DATA (INSERT / CREATE) --------------------
  Future<void> saveCurrentWeatherToServer() async {
    if (currentWeather == null) return;

    setState(() {
      isSaving = true;
    });

    try {
      // Catatan: dikirim lewat GET (bukan POST) sebagai jalur cadangan,
      // karena proxy/firewall di hosting sempat memblokir semua request
      // POST (error 415 dari openresty). Jika nanti pihak hosting sudah
      // memperbaiki hal ini, endpoint tetap mendukung POST seperti biasa.
      final Map<String, String> queryParams =
          toQueryParams(currentWeather!.toServerJson());

      final Uri uri = Uri.parse(ApiConfig.serverSaveUrl)
          .replace(queryParameters: queryParams);

      final http.Response response = await http.get(
        uri,
        headers: kBrowserLikeHeaders,
      );

      final Map<String, dynamic> decoded = await decodeJsonResponse(response);

      if (response.statusCode != 200 || decoded['success'] != true) {
        throw Exception(decoded['message'] ?? 'Gagal menyimpan data.');
      }

      showMessage('Data cuaca berhasil disimpan ke database server.');
      await loadHistoryFromServer();
      tabController.animateTo(1);
    } catch (e) {
      showMessage('Error menyimpan data: $e');
    } finally {
      setState(() {
        isSaving = false;
      });
    }
  }

  // -------------------- 3. AMBIL RIWAYAT (SELECT / READ) --------------------
  Future<void> loadHistoryFromServer() async {
    setState(() {
      isLoadingHistory = true;
    });

    try {
      final Uri uri = Uri.parse(ApiConfig.serverListUrl);

      final http.Response response = await http.get(
        uri,
        headers: kBrowserLikeHeaders,
      );

      final Map<String, dynamic> decoded = await decodeJsonResponse(response);

      if (response.statusCode != 200 || decoded['success'] != true) {
        throw Exception(decoded['message'] ?? 'Gagal mengambil riwayat.');
      }

      final dynamic data = decoded['data'];

      if (data is List) {
        setState(() {
          historyWeather = data
              .whereType<Map<String, dynamic>>()
              .map(WeatherModel.fromServerJson)
              .toList();
        });
      }
    } catch (e) {
      showMessage('Error mengambil riwayat: $e');
    } finally {
      setState(() {
        isLoadingHistory = false;
      });
    }
  }

  // -------------------- 4. PERBARUI DATA (UPDATE) --------------------
  Future<void> updateWeatherOnServer(
    WeatherModel weather,
    String notes,
    bool isFavorite,
  ) async {
    try {
      // Dikirim lewat GET (bukan POST) — lihat catatan di saveCurrentWeatherToServer().
      final Uri uri = Uri.parse(ApiConfig.serverUpdateUrl).replace(
        queryParameters: {
          'id': weather.id.toString(),
          'notes': notes,
          'is_favorite': isFavorite.toString(),
        },
      );

      final http.Response response = await http.get(
        uri,
        headers: kBrowserLikeHeaders,
      );

      final Map<String, dynamic> decoded = await decodeJsonResponse(response);

      if (response.statusCode != 200 || decoded['success'] != true) {
        throw Exception(decoded['message'] ?? 'Gagal memperbarui data.');
      }

      showMessage('Data cuaca berhasil diperbarui.');
      await loadHistoryFromServer();
    } catch (e) {
      showMessage('Error memperbarui data: $e');
    }
  }

  // -------------------- 5. HAPUS DATA (DELETE) --------------------
  Future<void> deleteWeatherFromServer(WeatherModel weather) async {
    try {
      // Dikirim lewat GET (bukan POST) — lihat catatan di saveCurrentWeatherToServer().
      final Uri uri = Uri.parse(ApiConfig.serverDeleteUrl).replace(
        queryParameters: {'id': weather.id.toString()},
      );

      final http.Response response = await http.get(
        uri,
        headers: kBrowserLikeHeaders,
      );

      final Map<String, dynamic> decoded = await decodeJsonResponse(response);

      if (response.statusCode != 200 || decoded['success'] != true) {
        throw Exception(decoded['message'] ?? 'Gagal menghapus data.');
      }

      showMessage('Data cuaca berhasil dihapus.');
      await loadHistoryFromServer();
    } catch (e) {
      showMessage('Error menghapus data: $e');
    }
  }

  void showMessage(String message) {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  Future<void> openEditDialog(WeatherModel weather) async {
    final TextEditingController notesController =
        TextEditingController(text: weather.notes ?? '');
    bool isFavoriteValue = weather.isFavorite;

    await showDialog<void>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text('Edit Data: ${weather.cityName}'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: notesController,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      labelText: 'Catatan pribadi',
                      hintText: 'Contoh: bawa payung sore hari',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Tandai sebagai favorit'),
                    value: isFavoriteValue,
                    onChanged: (value) {
                      setDialogState(() {
                        isFavoriteValue = value;
                      });
                    },
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Batal'),
                ),
                FilledButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    updateWeatherOnServer(
                      weather,
                      notesController.text.trim(),
                      isFavoriteValue,
                    );
                  },
                  child: const Text('Simpan'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> confirmDelete(WeatherModel weather) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Hapus Data Cuaca'),
          content: Text(
            'Yakin ingin menghapus data cuaca "${weather.cityName}" dari database?',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Batal'),
            ),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: Colors.red),
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Hapus'),
            ),
          ],
        );
      },
    );

    if (confirmed == true) {
      await deleteWeatherFromServer(weather);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Weather App'),
        bottom: TabBar(
          controller: tabController,
          tabs: const [
            Tab(icon: Icon(Icons.search), text: 'Cari Cuaca'),
            Tab(icon: Icon(Icons.history), text: 'Riwayat Tersimpan'),
          ],
        ),
      ),
      body: TabBarView(
        controller: tabController,
        children: [
          buildSearchTab(),
          buildHistoryTab(),
        ],
      ),
    );
  }

  // -------------------- TAB 1: PENCARIAN --------------------
  Widget buildSearchTab() {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          buildInfoBanner(),
          const SizedBox(height: 12),
          buildSearchForm(),
          const SizedBox(height: 12),
          if (isSearching)
            const Padding(
              padding: EdgeInsets.all(32),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (currentWeather != null)
            buildCurrentWeatherCard(currentWeather!)
          else
            const Card(
              elevation: 1,
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Center(
                  child: Text(
                    'Belum ada pencarian. Masukkan nama kota untuk melihat cuaca.',
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget buildInfoBanner() {
    return Card(
      elevation: 1,
      color: Colors.lightBlue.shade50,
      child: const Padding(
        padding: EdgeInsets.all(12),
        child: Text(
          'Aplikasi ini mengambil data cuaca terkini dari OpenWeatherMap API, '
          'lalu data yang dipilih dapat disimpan ke database server melalui REST API sendiri.',
        ),
      ),
    );
  }

  Widget buildSearchForm() {
    return Card(
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: searchController,
              decoration: const InputDecoration(
                labelText: 'Nama kota',
                hintText: 'Contoh: Jakarta, Surakarta, Tokyo',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.location_city),
              ),
              onSubmitted: (_) => searchWeatherFromApi(),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: isSearching ? null : searchWeatherFromApi,
                icon: const Icon(Icons.search),
                label: Text(isSearching ? 'Mencari...' : 'Cari Cuaca'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildCurrentWeatherCard(WeatherModel weather) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (weather.weatherIcon != null)
                  Image.network(
                    ApiConfig.iconUrl(weather.weatherIcon!),
                    width: 64,
                    height: 64,
                    errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.cloud, size: 48),
                  )
                else
                  const Icon(Icons.cloud, size: 48),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${weather.cityName}${weather.country != null ? ', ${weather.country}' : ''}',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        weather.weatherDescription ?? '-',
                        style: const TextStyle(fontStyle: FontStyle.italic),
                      ),
                    ],
                  ),
                ),
                Text(
                  weather.temperature != null
                      ? '${weather.temperature!.toStringAsFixed(1)}°C'
                      : '-',
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            Wrap(
              spacing: 16,
              runSpacing: 8,
              children: [
                buildWeatherStat(Icons.thermostat, 'Terasa seperti',
                    '${weather.feelsLike?.toStringAsFixed(1) ?? '-'}°C'),
                buildWeatherStat(Icons.water_drop, 'Kelembapan',
                    '${weather.humidity ?? '-'}%'),
                buildWeatherStat(Icons.air, 'Angin',
                    '${weather.windSpeed?.toStringAsFixed(1) ?? '-'} m/s'),
                buildWeatherStat(Icons.compress, 'Tekanan',
                    '${weather.pressure ?? '-'} hPa'),
                buildWeatherStat(Icons.arrow_downward, 'Min',
                    '${weather.tempMin?.toStringAsFixed(1) ?? '-'}°C'),
                buildWeatherStat(Icons.arrow_upward, 'Maks',
                    '${weather.tempMax?.toStringAsFixed(1) ?? '-'}°C'),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: isSaving ? null : saveCurrentWeatherToServer,
                icon: const Icon(Icons.cloud_upload),
                label: Text(
                  isSaving ? 'Menyimpan...' : 'Simpan ke Database',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildWeatherStat(IconData icon, String label, String value) {
    return SizedBox(
      width: 150,
      child: Row(
        children: [
          Icon(icon, size: 18, color: Colors.grey.shade700),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                ),
                Text(value,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // -------------------- TAB 2: RIWAYAT --------------------
  Widget buildHistoryTab() {
    return SafeArea(
      child: RefreshIndicator(
        onRefresh: loadHistoryFromServer,
        child: isLoadingHistory && historyWeather.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : historyWeather.isEmpty
                ? ListView(
                    children: const [
                      Padding(
                        padding: EdgeInsets.all(32),
                        child: Center(
                          child: Text(
                            'Belum ada data cuaca tersimpan.\nCari cuaca lalu tekan "Simpan ke Database".',
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    ],
                  )
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: historyWeather.length,
                    itemBuilder: (context, index) {
                      return buildHistoryCard(historyWeather[index]);
                    },
                  ),
      ),
    );
  }

  Widget buildHistoryCard(WeatherModel weather) {
    String formattedDate = '-';

    if (weather.createdAt != null) {
      try {
        final DateTime parsed = DateTime.parse(weather.createdAt!);
        formattedDate = DateFormat('dd MMM yyyy, HH:mm').format(parsed);
      } catch (_) {
        formattedDate = weather.createdAt!;
      }
    }

    return Card(
      elevation: 1,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                if (weather.weatherIcon != null)
                  Image.network(
                    ApiConfig.iconUrl(weather.weatherIcon!),
                    width: 48,
                    height: 48,
                    errorBuilder: (context, error, stackTrace) =>
                        const Icon(Icons.cloud, size: 36),
                  )
                else
                  const Icon(Icons.cloud, size: 36),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              '${weather.cityName}${weather.country != null ? ', ${weather.country}' : ''}',
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (weather.isFavorite)
                            const Icon(Icons.star,
                                color: Colors.amber, size: 20),
                        ],
                      ),
                      Text(
                        '${weather.temperature?.toStringAsFixed(1) ?? '-'}°C · '
                        '${weather.weatherDescription ?? '-'}',
                      ),
                      Text(
                        'Disimpan: $formattedDate',
                        style: TextStyle(
                          fontSize: 11,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (weather.notes != null && weather.notes!.trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text('Catatan: ${weather.notes}'),
                ),
              ),
            const SizedBox(height: 4),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () => openEditDialog(weather),
                  icon: const Icon(Icons.edit, size: 18),
                  label: const Text('Edit'),
                ),
                TextButton.icon(
                  onPressed: () => confirmDelete(weather),
                  icon: const Icon(Icons.delete, size: 18, color: Colors.red),
                  label: const Text(
                    'Hapus',
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
